"""Version information for the DJP Workflow system."""

VERSION = "1.0.1"
