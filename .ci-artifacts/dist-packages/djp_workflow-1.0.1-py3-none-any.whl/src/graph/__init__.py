"""Unified Resource Graph (URG) - Cross-connector indexing and search."""
