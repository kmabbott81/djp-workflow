"""Onboarding wizard for OpenAI Agents Workflows."""

from .wizard import run_wizard

__all__ = ["run_wizard"]
