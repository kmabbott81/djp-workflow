"""Debate → Judge → Publish workflow package."""

__version__ = "1.1.0-dev"
